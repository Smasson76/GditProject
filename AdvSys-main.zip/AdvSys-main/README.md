Project Title
GDIT Autority To Operate as a Service (ATOaaS)

Description
This is a prototype system for Authority to Operate as a Service (ATOaaS). The goal is to help automate Federal Risk Management Frameworks. 
