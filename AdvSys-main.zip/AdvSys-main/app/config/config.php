<?php
// Site Parameters
define('APPROOT', $app_path);
define('SITENAME', 'GDIT System Proposal');
define('URLROOT', 'localhost:8080/AdvSys/app');
    
// DB Parameters
define("DB_HOST", "localhost");
define("DB_USER", "ts_user");
define("DB_PASS", "pa55word");
define("DB_NAME", "gdit_advsys");

?>